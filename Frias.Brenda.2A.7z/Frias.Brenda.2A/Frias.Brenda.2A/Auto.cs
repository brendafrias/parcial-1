﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca_de_clases
{
    public class Auto : Vehiculo
    {
        #region Atributos
        public ETipo tipo;
        #endregion

        #region Metodos
        public Auto(string modelo, float precio, Fabricante fabri, ETipo tipo) : base(precio,modelo,fabri)
        {
            this.tipo = tipo;
        }

        public static explicit operator Single(Auto a)
        {
            return a.precio;
        }

        public static bool operator !=(Auto a, Auto b)
        {
            return !(a == b);
        }

        public static bool operator ==(Auto a, Auto b)
        {
            if (a.modelo == b.modelo && a.fabricante == b.fabricante && a.tipo == b.tipo)
            {
              
                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            return base.ToString();
        }

        #endregion
    }
}
