﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca_de_clases
{
     public abstract class Vehiculo
    {
        #region Atributos
        protected Fabricante fabricante;
        protected static Random generadorDeVelocidades;
        protected string modelo;
        protected float precio;
        protected int velocidadMaxima;
        #endregion

        #region Propiedades
        public int VelocidadMaxima
        { get
            { if (velocidadMaxima == 0)
                {
                    velocidadMaxima = generadorDeVelocidades.Next(100, 280);
                }
                return this.velocidadMaxima;
            }
        }
        #endregion

        #region Metodos
        public static explicit operator String(Vehiculo v)
        {
            return v.Mostrar(v);
        }

        private string Mostrar(Vehiculo v)
        {
            string sb = "FABRICANTE: " + v.fabricante.ToString() + "MODELO: " + v.modelo + "PRECIO: " + v.precio.ToString() + "VELOCIDAD MAXIMA: " + v.velocidadMaxima.ToString();

            return sb;
        }

        public static bool operator !=(Vehiculo a, Vehiculo b)
        {
            return !(a == b);
        }

        public static bool operator ==(Vehiculo a, Vehiculo b)
        {
            if (a.modelo == b.modelo && a.fabricante == b.fabricante)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region Constructores
        private Vehiculo()
        {
            generadorDeVelocidades = new Random();
        }
        public Vehiculo(float precio, string modelo, Fabricante fabri) : this()
        {
            this.precio = precio;
            this.modelo = modelo;
            this.fabricante = fabri;
        }

        public Vehiculo(string marca, EPais pais, string modelo, float precio)
        {
            Fabricante a = new Fabricante(marca, pais);
            this.modelo = modelo;
            this.precio = precio;


        }
        #endregion
    }
}
