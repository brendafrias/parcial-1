﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca_de_clases
{
    public class Concensionaria
    {
        #region Atributos
        private int capacidad;
        private List<Vehiculo> vehiculos;
        #endregion

        #region Propiedades
        public double PrecioDeAutos { get { return 1; } }
        public double PrecioDeMotos { get { return 1; } }
        public double PrecioTotal { get { return 1; } }
        #endregion

        #region Metodos
        private Concensionaria()
        {
            this.vehiculos = new List<Vehiculo>();
        }

        private Concensionaria(int capacidad) : this()
        {
            this.capacidad = capacidad;
        }

        public static implicit operator Concensionaria(int capacidad)
        {
            Concensionaria a = new Concensionaria(capacidad);
            return a.capacidad;
        }

        public static string Mostrar(Concensionaria c)
        {
            string sb= " ";
            foreach (Vehiculo item in c.vehiculos)
            {
                sb += item.ToString() + "; ";
            }
            return sb + "Capacidad: " + c.capacidad;
           
        }

        private double ObtenerPrecio(EVehiculo tipoVehiculo)
        {
            return 12;
        }

        public static bool operator !=(Concensionaria c, Vehiculo v)
        {
            return !(c == v);
        }

        public static bool operator ==(Concensionaria c, Vehiculo v)
        {
            bool flag = false;
            for (int i = 0; i < c.vehiculos.Count; i++)
            {
                if (c.vehiculos[i] == v)
                {
                    flag = true;
                    break;
                }

            }
            return flag;
        }

        public static Concensionaria operator +(Concensionaria c, Vehiculo v)
        {
            

            if(c.vehiculos.Capacity >= c.vehiculos.Count)
            {
                Console.WriteLine("Error no hay mas lugar");

                if (c == v)
                {
                    Console.WriteLine("Error el vehiculo ya se encuentra");
                    
                }
            }

         
            else
            {
                
                c.vehiculos.Add(v);
            }

            return c;
        }
        #endregion
    }
}
