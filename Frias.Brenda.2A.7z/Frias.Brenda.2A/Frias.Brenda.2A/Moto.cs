﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca_de_clases
{
    public class Moto : Vehiculo
    {
        #region Atributos
        public ECilindrada cilindrada;
        #endregion

        #region Metodos
        public override bool Equals(object obj)
        {
            return (this == (Moto)obj);
        }

        public static implicit operator Single(Moto m)
        {
            return m.precio;
        }

        public Moto(string marca,EPais pais,string modelo,float precio,ECilindrada cilindrada) :base(marca, pais, modelo, precio)
        {
            this.cilindrada = cilindrada;
        }

        public static bool operator !=(Moto a, Moto b)
        {
            return !(a == b);
        }

        public static bool operator ==(Moto a, Moto b)
        {
            if (a.modelo == b.modelo && a.fabricante == b.fabricante && a.cilindrada == b.cilindrada)
            {

                return true;
            }
            else
            {
                return false;
            }
        }

        public override string ToString()
        {
            return base.ToString();
        }
        #endregion
    }
}