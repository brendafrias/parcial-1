﻿using System;

namespace Biblioteca_de_clases

{
    public class Fabricante
    {
        #region Atributos
        private string marca;
        private EPais pais;
        #endregion

        #region Constructor
        public Fabricante(string marca, EPais pais)
        {
            this.marca = marca;
            this.pais = pais;
        }
        #endregion

        #region Operadores
        public static implicit operator String(Fabricante f)
        {
            return "FABRICANTE: " + f.marca + "-" +  f.pais;
        }

        public static bool operator !=(Fabricante a, Fabricante b)
        {
            return !(a == b);
        }

        public static bool operator ==(Fabricante a, Fabricante b)
        {
            if (a.marca == b.marca && a.pais == b.pais)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion
    }
}
