﻿public enum EVehiculo
{
    PrecioDeAutos,
    PrecioDeMotos,
    PrecioTotal
}